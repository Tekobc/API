require("dotenv").config();

const mongoose = require("mongoose");
const Table = require("../models/Table");
const Category = require("../models/Category");

const tables = require("./tables.seed");
const categories = require("./categories.seed");

async function seed() {
  try {
    await mongoose.connect(process.env.MONGO_URI);

    await Table.deleteMany({});
    await Category.deleteMany({});

    await Table.insertMany(tables);
    await Category.insertMany(categories);

    console.log("Mesas y categorías cargadas correctamente");

    await mongoose.connection.close();
    process.exit(0);
  } catch (error) {
    console.error("Error ejecutando los seeds:", error);
    process.exit(1);
  }
}

seed();
