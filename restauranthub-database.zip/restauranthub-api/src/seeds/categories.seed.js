module.exports = [
  {
    name: "platos principales",
    description: "Platos principales",
    icon: "food"
  },
  {
    name: "ensaladas",
    description: "Ensaladas",
    icon: "salad"
  },
  {
    name: "bebidas",
    description: "Bebidas",
    icon: "drink"
  }
];
