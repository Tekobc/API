module.exports = [
  {
    number: 1,
    capacity: 2,
    location: "ventana",
    status: "free",
    currentOrderId: null
  },
  {
    number: 2,
    capacity: 4,
    location: "interior",
    status: "free",
    currentOrderId: null
  },
  {
    number: 5,
    capacity: 6,
    location: "patio",
    status: "free",
    currentOrderId: null
  },
  {
    number: 8,
    capacity: 4,
    location: "interior",
    status: "free",
    currentOrderId: null
  }
];
