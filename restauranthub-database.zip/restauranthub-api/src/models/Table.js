const mongoose = require("mongoose");

const tableSchema = new mongoose.Schema(
  {
    number: {
      type: Number,
      required: true,
      unique: true
    },

    capacity: {
      type: Number,
      required: true,
      min: 1
    },

    location: {
      type: String,
      default: "interior"
    },

    status: {
      type: String,
      enum: ["free", "reserved", "occupied"],
      default: "free"
    },

    currentOrderId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Order",
      default: null
    }
  },
  {
    timestamps: true
  }
);

module.exports = mongoose.model("Table", tableSchema);
