const mongoose = require("mongoose");

const cashRegisterSchema = new mongoose.Schema(
  {
    openedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true
    },

    closedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null
    },

    openingAmount: {
      type: Number,
      required: true,
      min: 0
    },

    closingAmount: {
      type: Number,
      default: null,
      min: 0
    },

    status: {
      type: String,
      enum: ["open", "closed"],
      default: "open"
    },

    openedAt: {
      type: Date,
      default: Date.now
    },

    closedAt: {
      type: Date,
      default: null
    }
  },
  {
    timestamps: true
  }
);

module.exports = mongoose.model("CashRegister", cashRegisterSchema);
