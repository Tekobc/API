const mongoose = require("mongoose");

async function connectDatabase() {
  try {
    await mongoose.connect(process.env.MONGO_URI);

    console.log("Conexión con MongoDB establecida");
  } catch (error) {
    console.error("Error conectando con MongoDB:", error);
    throw error;
  }
}

module.exports = connectDatabase;
