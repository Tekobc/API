require("dotenv").config();

const env = {
  port: process.env.PORT || 3000,

  mongoUri: process.env.MONGO_URI,

  jwtSecret: process.env.JWT_SECRET,
  jwtExpiresIn: process.env.JWT_EXPIRES_IN || "1h",

  jwtRefreshSecret: process.env.JWT_REFRESH_SECRET,
  jwtRefreshExpiresIn: process.env.JWT_REFRESH_EXPIRES_IN || "7d",

  uploadDir: process.env.UPLOAD_DIR || "uploads/menu"
};

if (!env.mongoUri) {
  throw new Error("Falta la variable de entorno MONGO_URI");
}

if (!env.jwtSecret || !env.jwtRefreshSecret) {
  throw new Error("Faltan las variables de entorno JWT_SECRET o JWT_REFRESH_SECRET");
}

module.exports = env;
